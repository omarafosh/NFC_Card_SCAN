# NFC Reader Backend - Version 25

هذا المجلد يحتوي على كل ملفات الـ NFC Reader (Backend).

## 📁 الهيكل

```
backend/
├── nfc-reader-v25/      ← مجلد النشر (للموظفين)
│   ├── RUN.command
│   ├── nfc-reader-mac
│   └── README.txt
│
├── scripts/             ← الكود المصدري
│   ├── build-mac.sh     (سكريبت البناء)
│   ├── nfc-reader.js    (الكود الرئيسي)
│   └── ...
│
└── bin/                 ← البرامج المجمعة
    ├── nfc-reader-win.exe
    ├── nfc-reader-linux
    └── nfc-reader-macos-*
```

---

## 🔨 البناء

على الماك:
```bash
cd scripts
bash build-mac.sh
```

---

## 📦 النشر

للموظفين، اضغط مجلد `nfc-reader-v25` ووزعه.

---

## 🎯 الاستخدام

- **التطوير**: عدّل ملفات في `scripts/`
- **البناء**: استخدم `scripts/build-mac.sh`
- **النشر**: وزع `nfc-reader-v25/`
